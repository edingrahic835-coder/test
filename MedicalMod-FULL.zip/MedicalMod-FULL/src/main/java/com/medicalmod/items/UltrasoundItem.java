
package com.medicalmod.items;

import com.medicalmod.registry.ModItems;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class UltrasoundItem extends Item {
    public UltrasoundItem(Properties p) { super(p); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack off = player.getOffhandItem();
        if (!level.isClientSide) {
            if (off.is(ModItems.ULTRASOUND_GEL.get())) {
                player.displayClientMessage(Component.translatable("msg.medicalmod.ultrasound.clear"), true);
                off.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(InteractionHand.OFF_HAND));
            } else {
                player.displayClientMessage(Component.translatable("msg.medicalmod.ultrasound.nogel"), true);
            }
        }
        return InteractionResultHolder.sidedSuccess(player.getItemInHand(hand), level.isClientSide);
    }
}
