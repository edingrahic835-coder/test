
package com.medicalmod.items;

import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.network.chat.Component;

public class HeartMonitorItem extends Item {
    public HeartMonitorItem(Properties p) { super(p); }

    @Override
    public net.minecraft.world.InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        return net.minecraft.world.InteractionResultHolder.pass(player.getItemInHand(hand));
    }

    @Override
    public net.minecraft.world.InteractionResult useOn(UseOnContext ctx) {
        if (!ctx.getLevel().isClientSide && ctx.getPlayer()!=null) ctx.getPlayer().displayClientMessage(Component.translatable("msg.medicalmod.heartmonitor.place"), true);
        return net.minecraft.world.InteractionResult.sidedSuccess(ctx.getLevel().isClientSide);
    }

    @Override
    public net.minecraft.world.InteractionResultHolder<ItemStack> useOnEntity(net.minecraft.world.entity.player.Player player, LivingEntity entity, InteractionHand hand) {
        if (!player.level.isClientSide) {
            var tag = entity.getPersistentData();
            boolean mon = tag.getBoolean("medical.monitored");
            if (!mon) {
                tag.putBoolean("medical.monitored", true);
                tag.putInt("medical.spO2", 98);
                tag.putInt("medical.hr", 75);
                player.displayClientMessage(Component.translatable("msg.medicalmod.heartmonitor.attached"), true);
            } else {
                tag.putBoolean("medical.monitored", false);
                player.displayClientMessage(Component.translatable("msg.medicalmod.heartmonitor.detached"), true);
            }
        }
        return net.minecraft.world.InteractionResultHolder.sidedSuccess(player.getItemInHand(hand), player.level.isClientSide);
    }
}
