
package com.medicalmod.items;

import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public class DefibrillatorItem extends Item {
    public DefibrillatorItem(Properties p) { super(p); }

    @Override
    public InteractionResultHolder<ItemStack> useOnEntity(Player player, LivingEntity entity, InteractionHand hand) {
        if (!player.level.isClientSide) {
            var tag = entity.getPersistentData();
            if (!tag.getBoolean("medical.down")) {
                player.displayClientMessage(net.minecraft.network.chat.Component.translatable("msg.medicalmod.defib.notdown"), true);
                return InteractionResultHolder.sidedSuccess(player.getItemInHand(hand), player.level.isClientSide);
            }
            int chance = 30;
            if (tag.getBoolean("medical.cpr")) chance += 40;
            if (tag.getBoolean("medical.oxygen_mask")) chance += 20;
            int roll = RandomSource.createNewThreadLocalInstance().nextInt(100);
            if (roll < chance) {
                tag.putBoolean("medical.down", false);
                tag.putInt("medical.hr", 60 + RandomSource.createNewThreadLocalInstance().nextInt(40));
                tag.putInt("medical.spO2", Math.max(80, tag.getInt("medical.spO2")));
                player.displayClientMessage(net.minecraft.network.chat.Component.translatable("msg.medicalmod.defib.success"), true);
            } else {
                player.displayClientMessage(net.minecraft.network.chat.Component.translatable("msg.medicalmod.defib.fail"), true);
            }
        }
        return InteractionResultHolder.sidedSuccess(player.getItemInHand(hand), player.level.isClientSide);
    }
}
