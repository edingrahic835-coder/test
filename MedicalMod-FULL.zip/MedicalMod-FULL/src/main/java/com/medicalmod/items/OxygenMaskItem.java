
package com.medicalmod.items;

import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.item.Item;
import net.minecraft.network.chat.Component;

public class OxygenMaskItem extends Item {
    public OxygenMaskItem(Properties p) { super(p); }
    @Override
    public net.minecraft.world.InteractionResult useOn(UseOnContext ctx) {
        if (!ctx.getLevel().isClientSide && ctx.getPlayer()!=null) {
            var tag = ctx.getPlayer().getPersistentData();
            tag.putBoolean("medical.oxymask_on", true);
            ctx.getPlayer().displayClientMessage(Component.translatable("msg.medicalmod.oxymask.applied"), true);
        }
        return net.minecraft.world.InteractionResult.sidedSuccess(ctx.getLevel().isClientSide);
    }
}
