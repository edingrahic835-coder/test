
package com.medicalmod.items;

import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

public class StethoscopeItem extends Item {
    private final String tubeColor;
    private final String metal;
    public StethoscopeItem(Properties p, String tubeColor, String metal) { super(p); this.tubeColor = tubeColor; this.metal = metal; }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        if (!ctx.getLevel().isClientSide && ctx.getPlayer()!=null) ctx.getPlayer().displayClientMessage(Component.translatable("msg.medicalmod.stethoscope.listen"), true);
        return InteractionResult.sidedSuccess(ctx.getLevel().isClientSide);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        if (!level.isClientSide) player.displayClientMessage(Component.translatable("msg.medicalmod.stethoscope.self"), true);
        return InteractionResultHolder.sidedSuccess(player.getItemInHand(hand), level.isClientSide);
    }
}
